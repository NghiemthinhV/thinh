  using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using static Unity.Collections.AllocatorManager;

public class Player : MonoBehaviour
{

    public Blood blood;

    public float luongMauHienTai;

    public float luongMauToiDa = 10;

    public TextMeshProUGUI txtScore;

    public int score = 0;

    public GameObject panelEndGame;

    public Object weapon;

    public Object banana;

    public AudioClip jump;
    public AudioClip collectFruit;
    public AudioSource audioSource;

    Rigidbody2D rigidbody2D;
    bool isGrounded = false;




    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Trigger vao: " + other.gameObject.tag);

        if (other.gameObject.tag == "fruits")
        {
            audioSource.PlayOneShot(collectFruit);
            Destroy(other.gameObject);
            score++;
            txtScore.SetText(score.ToString());
        }

    }


private void OnCollisionEnter2D(Collision2D collision)
{

    if (collision.gameObject.tag == "Trap")
    {
        luongMauHienTai -= 2;
        blood.updateBlood(luongMauHienTai, luongMauToiDa);
        if (luongMauHienTai < 0)
        {
            Destroy(this.gameObject);

        }
    }
        if (collision.gameObject.tag == "obstacles")
        {
            panelEndGame.SetActive(true);
            Time.timeScale = 0;
        }
    }

    void Start()
    {
        rigidbody2D = GetComponent<Rigidbody2D>();
        audioSource = GetComponent<AudioSource>();
    }

    public void Jump ()
    {
        Debug.Log("Vao ham Jump");
        rigidbody2D.AddForce(Vector2.up * 6, ForceMode2D.Impulse);

        
    }
    public void Right()
    {
        Debug.Log("Vao ham Right");
        rigidbody2D.AddForce(Vector2.right * 2,ForceMode2D.Impulse);
    }

    public void Left()
    {
        Debug.Log("Vao ham Left");
        rigidbody2D.AddForce(Vector2.left * 2, ForceMode2D.Impulse);
    }

    public void RestartGame ()
    {
        panelEndGame.SetActive(false);
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        Time.timeScale = 1f;
    }

    

        // Update is called once per frame
        void Update()
    {
        
    }
}
