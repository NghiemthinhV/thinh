using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerManager : MonoBehaviour
{

    public Object weapon;

    public Object banana;

    public AudioClip jump;
    public AudioClip collectFruit;
    public AudioSource audioSource;
    // Start is called before the first frame update
    void Start()
    {
        Instantiate(weapon, gameObject.transform);

        audioSource = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
